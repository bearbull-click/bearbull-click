# BEARBULLS phased pilot — current terms

Accepted September 22, 2026. Supersedes earlier $100 mainnet targets, unranked early access and no-royalty proposals. These are the approved product rules, not a live sale announcement. The launch date is unset.

| Item | Rule |
| --- | --- |
| Collection ceiling | 10,000 unique creatures |
| Initial pilot | Exactly 100 creatures |
| Price target | $10 per creature, plus network gas |
| First 24 hours | Verified list of 10,000 recently active Robinhood NFT-holder wallets; one primary mint each; maximum 50 total early mints |
| From 24 hours | Public mint: one primary mint per wallet; 50 reserved creatures plus all unsold early inventory |
| From 48 hours | Top 1,000 ranked eligible wallets may reach three primary mints total, including earlier mints; subject to remaining inventory |
| Secondary royalty | Fixed 4.2% (420 basis points), ERC-2981, paid to the fixed project treasury |

Eligibility is permission to buy, not a reservation or free allocation. The bonus is two additional purchases for a wallet that already minted once; it is not three extra purchases. Transfers do not reset primary-mint counts. Counts apply across this collection's releases. A wallet that reaches its allowance cannot mint again in a later batch unless its applicable tier permits a higher lifetime count. Wallet limits are not a one-human rule.

Royalties are separate from the primary mint price. ERC-2981 reports a recipient and an amount in the sale's currency; marketplaces decide whether to honor it. A 100-unit resale requests 4.2 units, rounded down to the payment asset's smallest unit. The contract has no external method to raise the rate or redirect the royalty recipient. No royalty income, resale market, appreciation or sellout is promised. Standard: https://eips.ethereum.org/EIPS/eip-2981

## Implementation and status

`contracts/onchain/BearBullsPhasedDrop.sol` is the new **undeployed, testnet-only review candidate**. It accepts exactly 10 units of a six-decimal mock payment token. This is not evidence of real USDG support or an always-exact $10 exchange value. It permits chain 46630 and local 31337 only. A mainnet contract and canonical payment route still require separate review and deployment.

The existing v0.25 deployment and its source `BearBullsCreatureDrop.sol` stay unchanged: collection `0xBFE18B1F7FbF42Aa32B4E3455a020901d4D573EC` on chain 46630 charges 100 mock USDG and has no ERC-2981 implementation. Existing `mint.html` remains its rehearsal interface. New economics cannot be retroactively applied to that immutable contract.

The candidate starts paused. The owner registers exactly 100 frozen artworks, a future start timestamp and a nonzero Merkle root together. Those settings have no update functions. The owner can pause/resume primary minting and withdraw payment proceeds only to the fixed treasury. Pausing does not stop the 24/48-hour wall clock. Do not register an opening time until readiness and proofs are checked. Later releases require the previous one to sell out.

## Snapshot still required

No verified 10,000-wallet snapshot or top-1,000 ranking has been produced. Never substitute the archived Ethereum community snapshot or synthetic test addresses.

Prepare a publicly reproducible Robinhood snapshot using a fixed block and block hash from before the eligibility announcement. Verify relevant NFT collection addresses through their official sources. Publish the collections, cutoff, recent-activity window, exclusions and deterministic ranking before loading the root. Proposed activity methodology: distinct qualifying NFT activity days in the prior 30 days among current holders, with a reproducible hash tie-break; this methodology still needs validation against available chain data. Exclude documented escrow/treasury/burn addresses, not contract wallets by default. Do not rank by wallet balance, self-reported referrals or post-announcement transaction spam.

The intended list contains 10,000 unique wallets, including 1,000 top-tier wallets. If verifiable data cannot support that population, stop and revise the advertised list size explicitly; never pad it. A code test with dummy wallets is not snapshot evidence.

The contract leaf is `keccak256(bytes.concat(keccak256(abi.encode(chainId, collectionAddress, releaseIndex, collectorAddress, uint8 tier))))`. Use tier 1 for ordinary eligibility and tier 3 for the top tier, with sorted-pair Merkle proofs. The deployed collection address is part of every leaf. Publish proofs and the complete verification manifest before opening.

## Required before a public opening

Verify independent demand; validate the snapshot and proofs; finalize dollar pricing and the canonical USDG route; independently review the contract; prepare the mint interface for the new ABI; rehearse its complete wallet flow; deploy and verify new bytecode, royalty readback, immutable art and all minted media; publish provenance and the launch date. ETH and stock-token payment routes remain deferred until verified routes exist. No collection coin or pool is required.

// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;
import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";

/// @notice Freely issued TEST money. Not Paxos USDG; no dollar backing or redemption.
contract MockUSDG is ERC20 {
    constructor() ERC20("Mock USDG - NO VALUE", "mUSDG") {
        require(block.chainid == 46630 || block.chainid == 31337, "TESTNET_ONLY");
    }
    function decimals() public pure override returns (uint8) { return 6; }
    function faucet() external { _mint(msg.sender, 1000 * 1e6); }
}

// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

/// @notice Immutable, non-executable byte storage. Deploy every blob before the collection.
contract ImmutableBlob {
    constructor(bytes memory data) {
        require(data.length > 0 && data.length <= 24_575, "BLOB_SIZE");
        bytes memory runtime = bytes.concat(hex"00", data);
        assembly ("memory-safe") { return(add(runtime, 32), mload(runtime)) }
    }
}

library BlobReader {
    error InvalidBlobRange();
    function read(address blob, uint256 offset, uint256 length) internal view returns (bytes memory result) {
        if (blob.code.length < 2 || offset + length + 1 > blob.code.length) revert InvalidBlobRange();
        result = new bytes(length);
        assembly ("memory-safe") { extcodecopy(blob, add(result, 32), add(offset, 1), length) }
    }
    function all(address blob) internal view returns (bytes memory) {
        if (blob.code.length < 2) revert InvalidBlobRange();
        return read(blob, 0, blob.code.length - 1);
    }
    function u16(bytes memory data, uint256 at) internal pure returns (uint256) {
        return (uint256(uint8(data[at])) << 8) | uint256(uint8(data[at + 1]));
    }
}

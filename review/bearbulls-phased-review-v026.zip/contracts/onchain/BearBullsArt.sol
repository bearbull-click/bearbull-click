// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;
import {Base64} from "@openzeppelin/contracts/utils/Base64.sol";
import {Strings} from "@openzeppelin/contracts/utils/Strings.sol";
import {BlobReader} from "./ImmutableBlob.sol";

/// @notice Frozen PNG thumbnails, metadata and self-contained animated HTML.
/// @dev No setters, owner, proxy, network request, external URL, reveal or finalization path.
contract BearBullsArt {
    using BlobReader for address;
    using Strings for uint256;
    uint256 public constant ATTRIBUTE_COUNT = 30;
    uint256 public constant RECORD_SIZE = 71;
    uint256 public constant RECORDS_PER_PAGE = 346;
    uint256 public immutable supply;
    bytes32 public immutable provenanceHash;
    address[] private recordPages;
    address[] private thumbnailPages;
    address[] private dictionaryPages;
    address public immutable dictionaryIndex;
    address public immutable animationPrefix;
    address[] private animationSuffix;
    error InvalidArt();
    error UnknownSpecimen();

    struct Assets {
        address[] records;
        address[] thumbnails;
        address[] dictionary;
        address dictionaryIndex;
        address animationPrefix;
        address[] animationSuffix;
    }

    constructor(uint256 supply_, bytes32 provenance_, Assets memory assets) {
        if (supply_ == 0 || supply_ > 10_000 || provenance_ == bytes32(0)
            || assets.records.length != (supply_ + RECORDS_PER_PAGE - 1) / RECORDS_PER_PAGE
            || assets.thumbnails.length == 0 || assets.dictionary.length == 0 || assets.animationSuffix.length == 0) revert InvalidArt();
        supply = supply_; provenanceHash = provenance_;
        recordPages = assets.records; thumbnailPages = assets.thumbnails; dictionaryPages = assets.dictionary;
        dictionaryIndex = assets.dictionaryIndex; animationPrefix = assets.animationPrefix; animationSuffix = assets.animationSuffix;
        bytes memory hashes;
        // The order is the build manifest order; constructor binds every data byte to provenance.
        hashes = _commit(hashes, assets.records);
        hashes = _commit(hashes, assets.thumbnails);
        hashes = _commit(hashes, assets.dictionary);
        hashes = bytes.concat(hashes, _hashBlob(assets.dictionaryIndex), _hashBlob(assets.animationPrefix));
        hashes = _commit(hashes, assets.animationSuffix);
        if (keccak256(hashes) != provenance_) revert InvalidArt();
        for (uint256 p; p < assets.records.length; ++p) {
            uint256 count = p + 1 == assets.records.length ? supply_ - p * RECORDS_PER_PAGE : RECORDS_PER_PAGE;
            if (assets.records[p].code.length != count * RECORD_SIZE + 1) revert InvalidArt();
        }
        if ((assets.dictionaryIndex.code.length - 1) % 6 != 0) revert InvalidArt();
    }
    function _hashBlob(address blob) private view returns (bytes32) {
        if (blob.code.length < 2) revert InvalidArt();
        bytes1 first;
        assembly ("memory-safe") { let p := mload(0x40) extcodecopy(blob, p, 0, 1) first := mload(p) }
        if (first != 0x00 || blob.code.length > 24_576) revert InvalidArt();
        return blob.codehash;
    }
    function _commit(bytes memory hashes, address[] memory pages) private view returns (bytes memory) {
        for (uint256 i; i < pages.length; ++i) hashes = bytes.concat(hashes, _hashBlob(pages[i]));
        return hashes;
    }
    function _record(uint256 index) private view returns (bytes memory) {
        if (index >= supply) revert UnknownSpecimen();
        return recordPages[index / RECORDS_PER_PAGE].read((index % RECORDS_PER_PAGE) * RECORD_SIZE, RECORD_SIZE);
    }
    function specimenId(uint256 index) external view returns (uint256) { return BlobReader.u16(_record(index), 0); }
    function _word(uint256 id) private view returns (bytes memory) {
        bytes memory ref = dictionaryIndex.read(id * 6, 6);
        return dictionaryPages[BlobReader.u16(ref, 0)].read(BlobReader.u16(ref, 2), BlobReader.u16(ref, 4));
    }
    function imageURI(uint256 index) public view returns (string memory) {
        return _image(_record(index));
    }
    function _image(bytes memory r) private view returns (string memory) {
        bytes memory png = thumbnailPages[BlobReader.u16(r, 3)].read(BlobReader.u16(r, 5), BlobReader.u16(r, 7));
        return string.concat("data:image/png;base64,", Base64.encode(png));
    }
    function animationHTML(uint256 index) public view returns (string memory) { return _animation(_record(index)); }
    function _animation(bytes memory r) private view returns (string memory) {
        bytes memory html = bytes.concat(animationPrefix.all(), bytes(BlobReader.u16(r, 0).toString()), ",", bytes(uint256(uint8(r[2])).toString()));
        for (uint256 i; i < animationSuffix.length; ++i) html = bytes.concat(html, animationSuffix[i].all());
        return string(html);
    }
    function _padded(uint256 id) private pure returns (string memory) {
        bytes memory result = new bytes(4);
        for (uint256 i = 4; i > 0; --i) { result[i - 1] = bytes1(uint8(48 + id % 10)); id /= 10; }
        return string(result);
    }
    function _glyph(uint256 id) private pure returns (bytes memory result) {
        uint256 code = (((id + 1) * 4051) ^ 0x2b67) & 0x3fff;
        bytes16 alphabet = "0123456789ABCDEF";
        result = new bytes(6); result[0] = "G"; result[1] = "-";
        for (uint256 i; i < 4; ++i) result[5 - i] = alphabet[(code >> (4 * i)) & 15];
    }
    function tokenJSON(uint256 index) public view returns (string memory) {
        bytes memory r = _record(index);
        uint256 id = BlobReader.u16(r, 0);
        bytes memory attributes;
        for (uint256 i; i < ATTRIBUTE_COUNT; ++i) {
            if (i > 0) attributes = bytes.concat(attributes, ",");
            attributes = bytes.concat(attributes, _word(BlobReader.u16(r, 11 + i * 2)));
        }
        attributes = bytes.concat(attributes, ',{"trait_type":"Genesis Glyph","value":"', _glyph(id), '"}');
        bytes memory name = _word(BlobReader.u16(r, 9)); // JSON quoted, escaped by the build pipeline.
        // Replace the opening quote with the collection/id prefix; keep the escaped trailing quote.
        bytes memory tail = new bytes(name.length - 1);
        for (uint256 i = 1; i < name.length; ++i) tail[i - 1] = name[i];
        return string(bytes.concat(
            '{"name":"BearBull #', bytes(_padded(id)), unicode" — ", tail,
            ',"description":"An original animated BearBull caught somewhere between bear weather and bull conviction.","image":"',
            bytes(_image(r)), '","animation_url":"data:text/html;base64,', bytes(Base64.encode(bytes(_animation(r)))),
            '","attributes":[', attributes, "]}"
        ));
    }
    function tokenURI(uint256 index) external view returns (string memory) {
        return string.concat("data:application/json;base64,", Base64.encode(bytes(tokenJSON(index))));
    }
}

// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

import {BearBullsArt} from "./BearBullsArt.sol";
import {ERC721} from "@openzeppelin/contracts/token/ERC721/ERC721.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {IERC20Metadata} from "@openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";
import {Ownable2Step} from "@openzeppelin/contracts/access/Ownable2Step.sol";
import {Pausable} from "@openzeppelin/contracts/utils/Pausable.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";

/// @notice Creature-first paid rehearsal. No vault, rewards, pool or fungible collection token.
/// @dev TESTNET ONLY. 100 mock USD units is not a live USD quote or real USDG integration.
/// Art assignments cannot be replaced and use original specimen IDs. The release owner
/// must supply verified immutable BearBullsArt code; the Solidity type is not code authentication.
contract BearBullsCreatureDrop is ERC721, Ownable2Step, Pausable, ReentrancyGuard {
    using SafeERC20 for IERC20;
    uint256 public constant MAX_SUPPLY = 10_000;
    uint256 public constant MAX_RELEASE_SIZE = 100;
    uint256 public constant PRICE = 100 * 10 ** 6;
    IERC20 public immutable paymentToken;
    address public immutable treasury;
    uint256 public totalReleased;
    uint256 public totalMinted;
    mapping(address => bool) public hasMinted;

    struct Release {
        BearBullsArt art;
        bytes32 provenance;
        uint64 startsAt;
        uint16 count;
        uint16 minted;
    }
    struct Assignment {
        address art;
        uint16 artIndex;
        uint16 releaseIndex;
    }
    Release[] public releases;
    mapping(uint256 => Assignment) public assignments;

    error InvalidConfiguration();
    error PreviousReleaseNotSoldOut();
    error DuplicateSpecimen();
    error NotAvailable();
    error AlreadyMinted();
    error UnsupportedPayment();
    event ReleaseRegistered(uint256 indexed releaseIndex, address indexed art, bytes32 provenance, uint256 count, uint64 startsAt);
    event CreaturePurchased(address indexed collector, uint256 indexed tokenId, uint256 indexed releaseIndex, uint256 amount);
    event ProceedsWithdrawn(address indexed treasury, uint256 amount);

    constructor(address initialOwner, address treasury_, IERC20Metadata paymentToken_)
        ERC721("BEARBULLS Creature Drop Testnet", "BBC-TEST") Ownable(initialOwner)
    {
        if (block.chainid != 46630 && block.chainid != 31337) revert InvalidConfiguration();
        if (treasury_ == address(0) || treasury_ == address(this)
            || address(paymentToken_).code.length == 0 || paymentToken_.decimals() != 6) revert InvalidConfiguration();
        treasury = treasury_;
        paymentToken = IERC20(address(paymentToken_));
        _pause();
    }

    /// @notice Register at most 100 already-deployed creatures; a new batch requires the last to sell out.
    /// No future batch can overwrite a prior specimen or its media. Later releases need not happen.
    function registerRelease(BearBullsArt art_, uint64 startsAt) external onlyOwner {
        // Zero means open at registration time; the collection still starts paused.
        if (startsAt == 0) startsAt = uint64(block.timestamp);
        if (address(art_).code.length == 0 || startsAt < block.timestamp) revert InvalidConfiguration();
        uint256 count = art_.supply();
        bytes32 provenance = art_.provenanceHash();
        if (count == 0 || count > MAX_RELEASE_SIZE || totalReleased + count > MAX_SUPPLY || provenance == bytes32(0)) revert InvalidConfiguration();
        uint256 index = releases.length;
        if (index > 0 && releases[index - 1].minted != releases[index - 1].count) revert PreviousReleaseNotSoldOut();
        for (uint256 i; i < count; ++i) {
            uint256 id = art_.specimenId(i);
            if (id >= MAX_SUPPLY) revert InvalidConfiguration();
            if (assignments[id].art != address(0)) revert DuplicateSpecimen();
            assignments[id] = Assignment(address(art_), uint16(i), uint16(index));
        }
        releases.push(Release(art_, provenance, startsAt, uint16(count), 0));
        totalReleased += count;
        emit ReleaseRegistered(index, address(art_), provenance, count, startsAt);
    }

    /// @notice Choose a particular released creature. Payment and NFT delivery succeed or revert together.
    function mint(uint256 tokenId) external nonReentrant whenNotPaused {
        Assignment memory a = assignments[tokenId];
        if (a.art == address(0) || _ownerOf(tokenId) != address(0)) revert NotAvailable();
        Release storage r = releases[a.releaseIndex];
        if (block.timestamp < r.startsAt) revert NotAvailable();
        if (hasMinted[msg.sender]) revert AlreadyMinted();
        hasMinted[msg.sender] = true;
        ++r.minted;
        ++totalMinted;
        uint256 beforeBalance = paymentToken.balanceOf(address(this));
        paymentToken.safeTransferFrom(msg.sender, address(this), PRICE);
        if (paymentToken.balanceOf(address(this)) != beforeBalance + PRICE) revert UnsupportedPayment();
        _safeMint(msg.sender, tokenId);
        emit CreaturePurchased(msg.sender, tokenId, a.releaseIndex, PRICE);
    }

    function tokenURI(uint256 tokenId) public view override returns (string memory) {
        _requireOwned(tokenId);
        Assignment memory a = assignments[tokenId];
        return BearBullsArt(a.art).tokenURI(a.artIndex);
    }

    function releaseCount() external view returns (uint256) { return releases.length; }
    function pause() external onlyOwner { _pause(); }
    function resume() external onlyOwner { _unpause(); }
    function withdraw() external onlyOwner nonReentrant {
        uint256 amount = paymentToken.balanceOf(address(this));
        paymentToken.safeTransfer(treasury, amount);
        emit ProceedsWithdrawn(treasury, amount);
    }
}

// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;
import {BearBullsCreatureDrop as Drop} from "../contracts/onchain/BearBullsCreatureDrop.sol";
import {BearBullsArt} from "../contracts/onchain/BearBullsArt.sol";
import {ImmutableBlob} from "../contracts/onchain/ImmutableBlob.sol";
import {MockUSDG} from "../contracts/vault/MockUSDG.sol";
import {IERC20Metadata} from "@openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol";
import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import {IERC721Receiver} from "@openzeppelin/contracts/token/ERC721/IERC721Receiver.sol";
import {Strings} from "@openzeppelin/contracts/utils/Strings.sol";

interface DropVm {
    function prank(address) external;
    function startPrank(address) external;
    function stopPrank() external;
    function expectRevert() external;
    function expectRevert(bytes4) external;
    function warp(uint256) external;
    function chainId(uint256) external;
    function readFile(string calldata) external view returns(string memory);
    function readFileBinary(string calldata) external view returns(bytes memory);
    function parseJsonUint(string calldata,string calldata) external pure returns(uint256);
    function parseJsonBytes32(string calldata,string calldata) external pure returns(bytes32);
    function parseJsonString(string calldata,string calldata) external pure returns(string memory);
}
// Boundary fixture only. Actual immutable blob art is exercised separately below.
contract DropArtFixture {
    uint256 public immutable supply;
    bytes32 public constant provenanceHash=keccak256("fixture");
    uint256 offset;
    constructor(uint256 count,uint256 first){supply=count;offset=first;}
    function specimenId(uint256 index) external view returns(uint256){return offset+index;}
    function tokenURI(uint256 index) external pure returns(string memory){return string.concat("fixture:",Strings.toString(index));}
}
contract DropFeeToken is ERC20 {
    constructor() ERC20("Fee fixture","FEE"){_mint(msg.sender,1000e6);}
    function decimals() public pure override returns(uint8){return 6;}
    function _update(address from,address to,uint256 amount) internal override {
        if(from!=address(0)&&to!=address(0)){super._update(from,address(0),1);super._update(from,to,amount-1);}
        else super._update(from,to,amount);
    }
}
contract DropWrongDecimals is ERC20 { constructor() ERC20("Wrong","WRONG") {} }
contract DropReceiver is IERC721Receiver {
    Drop drop;MockUSDG usd;
    bool public blocked;bool public reject;
    bytes32 public media;
    constructor(Drop d,MockUSDG u,bool reject_){drop=d;usd=u;reject=reject_;}
    function buy(uint256 id) external {usd.faucet();usd.approve(address(drop),100e6);drop.mint(id);}
    function onERC721Received(address,address,uint256 id,bytes calldata) external returns(bytes4){
        require(msg.sender==address(drop));media=keccak256(bytes(drop.tokenURI(id)));
        try drop.mint(id+1) {} catch {blocked=true;}
        require(!reject,"REJECT");return this.onERC721Received.selector;
    }
}
contract BearBullsCreatureDropTest is IERC721Receiver {
    DropVm constant vm=DropVm(address(uint160(uint256(keccak256("hevm cheat code")))));
    address constant ALICE=address(0xA11CE);
    address constant TREASURY=address(0xBEEF);
    MockUSDG usd;Drop drop;
    function setUp() public {vm.warp(100);usd=new MockUSDG();drop=new Drop(address(this),TREASURY,usd);usd.faucet();usd.approve(address(drop),100e6);}
    function fixture(uint256 n,uint256 offset) internal returns(BearBullsArt){return BearBullsArt(address(new DropArtFixture(n,offset)));}
    function open(uint256 n) internal {drop.registerRelease(fixture(n,0),100);drop.resume();}
    function buyAs(address collector,uint256 id) internal {vm.startPrank(collector);usd.faucet();usd.approve(address(drop),100e6);drop.mint(id);vm.stopPrank();}
    function onERC721Received(address,address,uint256,bytes calldata) external pure returns(bytes4){return this.onERC721Received.selector;}

    function testStartsPausedAndRequiresReleasedSpecimenAndStartTime() public {
        drop.registerRelease(fixture(2,0),200);
        vm.expectRevert();drop.mint(0);drop.resume();
        vm.expectRevert(Drop.NotAvailable.selector);drop.mint(0);
        vm.warp(200);vm.expectRevert(Drop.NotAvailable.selector);drop.mint(2);
        vm.expectRevert();drop.tokenURI(0);drop.mint(1);
        require(drop.ownerOf(1)==address(this)&&drop.totalMinted()==1);
    }
    function testChargesExactly100MockUsdAndWithdrawsOnlyToTreasury() public {
        open(2);drop.mint(1);require(usd.balanceOf(address(this))==900e6&&usd.balanceOf(address(drop))==100e6);
        vm.prank(ALICE);vm.expectRevert();drop.withdraw();
        drop.withdraw();require(usd.balanceOf(TREASURY)==100e6&&usd.balanceOf(address(drop))==0);
    }
    function testCannotRemintOrMintAgainAfterTransferring() public {
        open(2);drop.mint(0);drop.transferFrom(address(this),ALICE,0);
        vm.expectRevert(Drop.AlreadyMinted.selector);drop.mint(1);
        vm.prank(ALICE);vm.expectRevert(Drop.NotAvailable.selector);drop.mint(0);
        require(drop.totalMinted()==1);
    }
    function testMissingAllowanceRollsBackSupplyAndEligibility() public {
        open(2);usd.approve(address(drop),0);vm.expectRevert();drop.mint(0);
        require(drop.totalMinted()==0&&!drop.hasMinted(address(this))&&usd.balanceOf(address(drop))==0);
        usd.approve(address(drop),100e6);drop.mint(0);
    }
    function testRejectingRecipientRollsBackPaymentAndMint() public {
        open(2);DropReceiver receiver=new DropReceiver(drop,usd,true);
        vm.expectRevert();receiver.buy(0);
        require(drop.totalMinted()==0&&!drop.hasMinted(address(receiver))&&usd.balanceOf(address(drop))==0);
    }
    function testReceiverReentrancyIsBlockedAndMetadataIsImmediate() public {
        open(2);DropReceiver receiver=new DropReceiver(drop,usd,false);receiver.buy(0);
        require(receiver.blocked()&&receiver.media()==keccak256(bytes(drop.tokenURI(0))));
        require(drop.totalMinted()==1&&usd.balanceOf(address(drop))==100e6);
    }
    function testNextReleaseRequiresSelloutAndCannotReplaceEarlierArt() public {
        open(2);BearBullsArt next=fixture(2,2);
        vm.expectRevert(Drop.PreviousReleaseNotSoldOut.selector);drop.registerRelease(next,100);
        drop.mint(0);bytes32 original=keccak256(bytes(drop.tokenURI(0)));buyAs(ALICE,1);
        drop.registerRelease(next,100);require(drop.totalReleased()==4&&drop.releaseCount()==2);
        require(keccak256(bytes(drop.tokenURI(0)))==original);
        buyAs(address(0x1234),2);buyAs(address(0x1235),3);
        BearBullsArt duplicate=fixture(1,0);vm.expectRevert(Drop.DuplicateSpecimen.selector);drop.registerRelease(duplicate,100);
        require(drop.totalReleased()==4&&drop.releaseCount()==2);
    }
    function testOwnerOnlyReleaseAndPauseAndMetadataSurvivesOwnershipChange() public {
        BearBullsArt a=fixture(2,0);vm.prank(ALICE);vm.expectRevert();drop.registerRelease(a,100);
        open(2);drop.mint(0);bytes32 original=keccak256(bytes(drop.tokenURI(0)));
        vm.prank(ALICE);vm.expectRevert();drop.pause();drop.pause();
        drop.transferOwnership(ALICE);vm.prank(ALICE);drop.acceptOwnership();
        require(keccak256(bytes(drop.tokenURI(0)))==original);drop.transferFrom(address(this),ALICE,0);
        require(drop.ownerOf(0)==ALICE);
    }
    function testZeroStartRegistersImmediatelyButStillNeedsOwnerToOpen() public {
        vm.warp(1000);drop.registerRelease(fixture(1,0),0);
        (,,uint64 start,,)=drop.releases(0);require(start==1000&&drop.paused());
        vm.expectRevert();drop.mint(0);drop.resume();drop.mint(0);
    }
    function testFullHundredCreatureBatchSupportsFinalCanonicalId() public {
        drop.registerRelease(fixture(100,9900),100);drop.resume();drop.mint(9999);
        require(drop.totalReleased()==100&&drop.ownerOf(9999)==address(this));
        (address renderer,uint16 index,)=drop.assignments(9999);
        require(renderer!=address(0)&&index==99);
    }
    function testRejectsInvalidReleaseSizeIdsPastDateAndZeroArt() public {
        for(uint256 i;i<4;i++){
            BearBullsArt a=fixture(i==0?0:i==1?101:1,i==2?10000:0);
            vm.expectRevert(Drop.InvalidConfiguration.selector);drop.registerRelease(a,i==3?99:100);
        }
        vm.expectRevert(Drop.InvalidConfiguration.selector);drop.registerRelease(BearBullsArt(address(0)),100);
        require(drop.totalReleased()==0);
    }
    function testRejectsMainnetWrongDecimalsAndZeroTreasury() public {
        vm.expectRevert(Drop.InvalidConfiguration.selector);new Drop(address(this),address(0),usd);
        DropWrongDecimals wrong=new DropWrongDecimals();vm.expectRevert(Drop.InvalidConfiguration.selector);new Drop(address(this),TREASURY,IERC20Metadata(address(wrong)));
        vm.chainId(4663);vm.expectRevert(Drop.InvalidConfiguration.selector);new Drop(address(this),TREASURY,usd);
    }
    function testFeeOnTransferCannotUnderpay() public {
        DropFeeToken fee=new DropFeeToken();Drop taxed=new Drop(address(this),TREASURY,fee);
        taxed.registerRelease(fixture(1,0),100);taxed.resume();fee.approve(address(taxed),100e6);
        vm.expectRevert(Drop.UnsupportedPayment.selector);taxed.mint(0);
        require(taxed.totalMinted()==0&&fee.balanceOf(address(taxed))==0&&fee.balanceOf(address(this))==1000e6);
    }
    function testFuzzPaymentsMatchMintedSupply(uint8 raw) public {
        uint256 count=uint256(raw)%10+1;open(count);
        for(uint256 i;i<count;i++)buyAs(address(uint160(0x1000+i)),i);
        require(drop.totalMinted()==count&&drop.totalReleased()==count&&usd.balanceOf(address(drop))==count*100e6);
    }
    function testRealBlobArtUsesOriginalSpecimenIdAndImmediateThumbnail() public {
        string memory manifest=vm.readFile("output/onchain/rehearsal/manifest.json");
        BearBullsArt.Assets memory assets;
        uint256 count=vm.parseJsonUint(manifest,".stats.blobCount");
        // Count and allocate arrays from the committed manifest, then preserve its order.
        uint256[4] memory lengths;
        for(uint256 i;i<count;i++){
            string memory prefix=string.concat(".blobs[",Strings.toString(i),"]");
            bytes32 kind=keccak256(bytes(vm.parseJsonString(manifest,string.concat(prefix,".group"))));
            if(kind==keccak256("records"))lengths[0]++;
            if(kind==keccak256("thumbnails"))lengths[1]++;
            if(kind==keccak256("dictionary"))lengths[2]++;
            if(kind==keccak256("animationSuffix"))lengths[3]++;
        }
        assets.records=new address[](lengths[0]);assets.thumbnails=new address[](lengths[1]);assets.dictionary=new address[](lengths[2]);assets.animationSuffix=new address[](lengths[3]);
        uint256[4] memory cursor;
        for(uint256 i;i<count;i++){
            string memory prefix=string.concat(".blobs[",Strings.toString(i),"]");
            bytes32 kind=keccak256(bytes(vm.parseJsonString(manifest,string.concat(prefix,".group"))));
            address blob=address(new ImmutableBlob(vm.readFileBinary(string.concat("output/onchain/rehearsal/",vm.parseJsonString(manifest,string.concat(prefix,".file"))))));
            if(kind==keccak256("records"))assets.records[cursor[0]++]=blob;
            else if(kind==keccak256("thumbnails"))assets.thumbnails[cursor[1]++]=blob;
            else if(kind==keccak256("dictionary"))assets.dictionary[cursor[2]++]=blob;
            else if(kind==keccak256("animationSuffix"))assets.animationSuffix[cursor[3]++]=blob;
            else if(kind==keccak256("dictionaryIndex"))assets.dictionaryIndex=blob;
            else if(kind==keccak256("animationPrefix"))assets.animationPrefix=blob;
        }
        BearBullsArt realArt=new BearBullsArt(vm.parseJsonUint(manifest,".supply"),vm.parseJsonBytes32(manifest,".provenance"),assets);
        drop.registerRelease(realArt,100);drop.resume();uint256 specimen=realArt.specimenId(8);drop.mint(specimen);
        require(specimen==3820&&drop.ownerOf(3820)==address(this));
        require(keccak256(bytes(drop.tokenURI(specimen)))==keccak256(bytes(realArt.tokenURI(8))));
        require(bytes(realArt.imageURI(8)).length>1000);
    }
}

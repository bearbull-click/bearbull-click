// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;
import {BearBullsPhasedDrop as Drop} from "../contracts/onchain/BearBullsPhasedDrop.sol";
import {BearBullsArt} from "../contracts/onchain/BearBullsArt.sol";
import {MockUSDG} from "../contracts/vault/MockUSDG.sol";
import {IERC721Receiver} from "@openzeppelin/contracts/token/ERC721/IERC721Receiver.sol";
import {DropArtFixture, DropFeeToken, DropWrongDecimals, DropVm} from "./BearBullsCreatureDrop.t.sol";
import {IERC20Metadata} from "@openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol";
import {ImmutableBlob} from "../contracts/onchain/ImmutableBlob.sol";
import {Strings} from "@openzeppelin/contracts/utils/Strings.sol";

interface PhasedVm {
    function warp(uint256) external;
    function prank(address) external;
    function startPrank(address) external;
    function stopPrank() external;
    function expectRevert() external;
    function expectRevert(bytes4) external;
    function chainId(uint256) external;
}

contract PhasedReceiver is IERC721Receiver {
    Drop d;
    MockUSDG u;
    bool reject;
    bool public blocked;
    bytes32 public media;

    constructor(Drop a, MockUSDG b, bool c) {
        d = a;
        u = b;
        reject = c;
    }

    function buy() external {
        u.faucet();
        u.approve(address(d), 10e6);
        d.mint(90, 0, new bytes32[](0));
    }

    function onERC721Received(address, address, uint256 id, bytes calldata) external returns (bytes4) {
        require(msg.sender == address(d));
        media = keccak256(bytes(d.tokenURI(id)));
        try d.mint(91, 0, new bytes32[](0)) {}
            catch {
            blocked = true;
        }
        require(!reject, "REJECT");
        return this.onERC721Received.selector;
    }
}

contract BearBullsPhasedDropTest {
    PhasedVm constant vm = PhasedVm(address(uint160(uint256(keccak256("hevm cheat code")))));
    uint64 constant START = 2000;
    address constant TREASURY = address(0xBEEF);
    Drop d;
    MockUSDG u;
    bytes32 root;

    function who(uint256 n) internal pure returns (address) {
        return address(uint160(0x1000 + n));
    }

    function tier(uint256 n) internal pure returns (uint8) {
        return n < 3 ? 3 : 1;
    }

    function pair(bytes32 a, bytes32 b) internal pure returns (bytes32) {
        return a < b ? keccak256(abi.encodePacked(a, b)) : keccak256(abi.encodePacked(b, a));
    }

    function tree(uint256 selected) internal view returns (bytes32, bytes32[] memory proof) {
        bytes32[] memory level = new bytes32[](128);
        proof = new bytes32[](7);
        for (uint256 i; i < 128; i++) {
            level[i] = d.allowlistLeaf(0, who(i), tier(i));
        }
        uint256 pos = selected;
        uint256 depth;
        for (uint256 count = 128; count > 1; count /= 2) {
            proof[depth++] = level[pos ^ 1];
            for (uint256 i; i < count; i += 2) {
                level[i / 2] = pair(level[i], level[i + 1]);
            }
            pos /= 2;
        }
        return (level[0], proof);
    }

    function proofFor(uint256 n) internal view returns (bytes32[] memory proof) {
        (, proof) = tree(n);
    }

    function setUp() public {
        vm.warp(1000);
        u = new MockUSDG();
        d = new Drop(address(this), TREASURY, u);
        (root,) = tree(0);
        d.registerRelease(BearBullsArt(address(new DropArtFixture(100, 0))), START, root);
        d.resume();
        vm.warp(START);
    }

    function buy(uint256 n, uint256 id, uint8 t, bytes32[] memory p) internal {
        vm.startPrank(who(n));
        u.faucet();
        u.approve(address(d), 10e6);
        d.mint(id, t, p);
        vm.stopPrank();
    }

    function early(uint256 n, uint256 id) internal {
        buy(n, id, tier(n), proofFor(n));
    }

    function publicBuy(uint256 n, uint256 id) internal {
        buy(n, id, 0, new bytes32[](0));
    }

    function testBeforeStartClosedAndExactStartOpens() public {
        bytes32[] memory p = proofFor(0);
        vm.warp(START - 1);
        vm.prank(who(0));
        vm.expectRevert(Drop.NotAvailable.selector);
        d.mint(0, 3, p);
        vm.warp(START);
        early(0, 0);
        require(d.ownerOf(0) == who(0));
    }

    function testEarlyRequiresCorrectWalletTierAndProof() public {
        bytes32[] memory p = proofFor(0);
        vm.prank(who(1));
        vm.expectRevert(Drop.InvalidProof.selector);
        d.mint(0, 3, p);
        vm.prank(who(0));
        vm.expectRevert(Drop.InvalidProof.selector);
        d.mint(0, 1, p);
        vm.prank(who(0));
        vm.expectRevert(Drop.InvalidProof.selector);
        d.mint(0, 0, new bytes32[](0));
        early(0, 0);
    }

    function testEveryTierLimitedToOneBefore48Hours() public {
        early(0, 0);
        vm.warp(START + 24 hours);
        bytes32[] memory p = proofFor(0);
        vm.prank(who(0));
        vm.expectRevert(Drop.WalletLimit.selector);
        d.mint(1, 3, p);
        vm.warp(START + 48 hours - 1);
        vm.prank(who(0));
        vm.expectRevert(Drop.WalletLimit.selector);
        d.mint(1, 3, p);
    }

    function testFirst50CannotConsumePublicReserveAndExact24HoursOpens() public {
        for (uint256 i; i < 50; i++) {
            early(i, i);
        }
        bytes32[] memory p = proofFor(50);
        vm.warp(START + 24 hours - 1);
        vm.prank(who(50));
        vm.expectRevert(Drop.EarlyAllocationSoldOut.selector);
        d.mint(50, 1, p);
        require(d.totalMinted() == 50);
        vm.warp(START + 24 hours);
        publicBuy(200, 50);
        require(d.totalMinted() == 51);
    }

    function testAllLeftoversAvailableAfter24Hours() public {
        for (uint256 i; i < 12; i++) {
            early(i, i);
        }
        vm.warp(START + 24 hours);
        for (uint256 i = 12; i < 100; i++) {
            publicBuy(200 + i, i);
        }
        require(d.totalMinted() == 100 && u.balanceOf(address(d)) == 1000e6);
    }

    function testTopTierGetsThreeTotalAtExact48Hours() public {
        early(0, 0);
        vm.warp(START + 48 hours);
        early(0, 1);
        early(0, 2);
        bytes32[] memory p = proofFor(0);
        vm.prank(who(0));
        vm.expectRevert(Drop.WalletLimit.selector);
        d.mint(3, 3, p);
        require(d.mintedBy(who(0)) == 3 && u.balanceOf(address(d)) == 30e6);
    }

    function testTopTierCanStartAfter48Hours() public {
        vm.warp(START + 48 hours);
        early(1, 0);
        early(1, 1);
        early(1, 2);
        require(d.mintedBy(who(1)) == 3);
    }

    function testPublicFirstMintCountsTowardTopTierThree() public {
        vm.warp(START + 24 hours);
        publicBuy(0, 0);
        vm.warp(START + 48 hours);
        early(0, 1);
        early(0, 2);
        require(d.mintedBy(who(0)) == 3);
    }

    function testOrdinaryEligibleAndPublicRemainAtOneAfter48Hours() public {
        vm.warp(START + 48 hours);
        early(4, 0);
        publicBuy(200, 1);
        bytes32[] memory p = proofFor(4);
        vm.prank(who(4));
        vm.expectRevert(Drop.WalletLimit.selector);
        d.mint(2, 1, p);
        vm.prank(who(200));
        vm.expectRevert(Drop.WalletLimit.selector);
        d.mint(3, 0, new bytes32[](0));
    }

    function testForgedBonusCannotIncreaseAllowance() public {
        vm.warp(START + 48 hours);
        bytes32[] memory p = proofFor(4);
        vm.prank(who(4));
        vm.expectRevert(Drop.InvalidProof.selector);
        d.mint(0, 3, p);
        vm.prank(who(200));
        vm.expectRevert(Drop.InvalidProof.selector);
        d.mint(0, 3, new bytes32[](0));
    }

    function testTransferDoesNotResetPrimaryLimit() public {
        early(0, 0);
        vm.prank(who(0));
        d.transferFrom(who(0), who(300), 0);
        bytes32[] memory p = proofFor(0);
        vm.prank(who(0));
        vm.expectRevert(Drop.WalletLimit.selector);
        d.mint(1, 3, p);
        vm.warp(START + 48 hours);
        early(0, 1);
        early(0, 2);
        require(d.mintedBy(who(0)) == 3);
    }

    function testProofBoundToChainContractAndRelease() public {
        bytes32 original = d.allowlistLeaf(0, who(0), 3);
        require(original != d.allowlistLeaf(1, who(0), 3));
        Drop other = new Drop(address(this), TREASURY, u);
        require(original != other.allowlistLeaf(0, who(0), 3));
        bytes32[] memory p = proofFor(0);
        vm.chainId(46630);
        require(original != d.allowlistLeaf(0, who(0), 3));
        vm.prank(who(0));
        vm.expectRevert(Drop.InvalidProof.selector);
        d.mint(0, 3, p);
    }

    function testPauseDoesNotResetPhaseClock() public {
        d.pause();
        bytes32[] memory p = proofFor(0);
        vm.prank(who(0));
        vm.expectRevert();
        d.mint(0, 3, p);
        vm.warp(START + 24 hours);
        d.resume();
        publicBuy(200, 0);
    }

    function testMissingApprovalRollsBackCounters() public {
        bytes32[] memory p = proofFor(0);
        vm.prank(who(0));
        vm.expectRevert();
        d.mint(0, 3, p);
        require(d.totalMinted() == 0 && d.mintedBy(who(0)) == 0);
        early(0, 0);
    }

    function testNoDoubleMintOrUnregisteredId() public {
        early(0, 0);
        bytes32[] memory p = proofFor(1);
        vm.prank(who(1));
        vm.expectRevert(Drop.NotAvailable.selector);
        d.mint(0, 3, p);
        vm.prank(who(1));
        vm.expectRevert(Drop.NotAvailable.selector);
        d.mint(100, 3, p);
    }

    function testRoyalty420BasisPointsAndInterfaces() public {
        require(d.supportsInterface(0x2a55205a) && d.supportsInterface(0x80ac58cd) && d.supportsInterface(0x5b5e139f));
        require(!d.supportsInterface(0xffffffff));
        (address recipient, uint256 royalty) = d.royaltyInfo(0, 100e6);
        require(recipient == TREASURY && royalty == 4200000);
        (, royalty) = d.royaltyInfo(0, 10e6);
        require(royalty == 420000);
        early(0, 0);
        require(u.balanceOf(address(d)) == 10e6);
    }

    function testFuzzRoyaltyProportional(uint128 sale) public view {
        (address recipient, uint256 royalty) = d.royaltyInfo(9999, sale);
        require(recipient == TREASURY && royalty == uint256(sale) * 420 / 10000);
    }

    function testRoyaltyAndTreasurySurviveOwnershipChange() public {
        d.transferOwnership(who(400));
        vm.prank(who(400));
        d.acceptOwnership();
        (address recipient,) = d.royaltyInfo(1, 1e18);
        require(recipient == TREASURY);
        early(0, 0);
        vm.prank(who(400));
        d.withdraw();
        require(u.balanceOf(TREASURY) == 10e6);
    }

    function testWithdrawAndPauseOwnerOnly() public {
        early(0, 0);
        vm.prank(who(0));
        vm.expectRevert();
        d.withdraw();
        vm.prank(who(0));
        vm.expectRevert();
        d.pause();
        d.withdraw();
        require(u.balanceOf(TREASURY) == 10e6);
    }

    function testReceiverReentrancyAndImmediateMedia() public {
        vm.warp(START + 24 hours);
        PhasedReceiver receiver = new PhasedReceiver(d, u, false);
        receiver.buy();
        require(receiver.blocked() && receiver.media() == keccak256(bytes(d.tokenURI(90))));
        require(d.totalMinted() == 1);
    }

    function testRejectingReceiverRollsBackPaymentAndCounters() public {
        vm.warp(START + 24 hours);
        PhasedReceiver receiver = new PhasedReceiver(d, u, true);
        vm.expectRevert();
        receiver.buy();
        require(d.totalMinted() == 0 && d.mintedBy(address(receiver)) == 0 && u.balanceOf(address(d)) == 0);
    }

    function testRegistrationCannotChangeAnActiveBatch() public {
        BearBullsArt next = BearBullsArt(address(new DropArtFixture(100, 100)));
        vm.expectRevert(Drop.PreviousReleaseNotSoldOut.selector);
        d.registerRelease(next, START + 1, root);
        vm.prank(who(0));
        vm.expectRevert();
        d.registerRelease(BearBullsArt(address(1)), START + 1, root);
    }

    function testRegistrationRejectsZeroRootPastTimeAndWrongSize() public {
        Drop fresh = new Drop(address(this), TREASURY, u);
        BearBullsArt art = BearBullsArt(address(new DropArtFixture(100, 0)));
        vm.expectRevert(Drop.InvalidConfiguration.selector);
        fresh.registerRelease(art, START, root);
        vm.expectRevert(Drop.InvalidConfiguration.selector);
        fresh.registerRelease(art, START + 1, bytes32(0));
        BearBullsArt small = BearBullsArt(address(new DropArtFixture(99, 0)));
        vm.expectRevert(Drop.InvalidConfiguration.selector);
        fresh.registerRelease(small, START + 1, root);
    }

    function testRejectsMainnetWrongDecimalsAndZeroTreasury() public {
        vm.expectRevert(Drop.InvalidConfiguration.selector);
        new Drop(address(this), address(0), u);
        DropWrongDecimals wrong = new DropWrongDecimals();
        vm.expectRevert(Drop.InvalidConfiguration.selector);
        new Drop(address(this), TREASURY, IERC20Metadata(address(wrong)));
        vm.chainId(4663);
        vm.expectRevert(Drop.InvalidConfiguration.selector);
        new Drop(address(this), TREASURY, u);
    }

    function testFeeOnTransferRejected() public {
        DropFeeToken fee = new DropFeeToken();
        Drop taxed = new Drop(address(this), TREASURY, fee);
        taxed.registerRelease(BearBullsArt(address(new DropArtFixture(100, 0))), START + 1, root);
        taxed.resume();
        vm.warp(START + 24 hours + 1);
        fee.approve(address(taxed), 10e6);
        vm.expectRevert(Drop.UnsupportedPayment.selector);
        taxed.mint(0, 0, new bytes32[](0));
        require(taxed.totalMinted() == 0 && fee.balanceOf(address(taxed)) == 0);
    }

    function testNewPhasedDropMintsRealFrozenPNGAndHTML() public {
        DropVm fixtureVm = DropVm(address(vm));
        string memory manifest = fixtureVm.readFile("output/onchain/final-v025/manifest.json");
        BearBullsArt.Assets memory assets;
        uint256 count = fixtureVm.parseJsonUint(manifest, ".stats.blobCount");
        // Count and allocate arrays from the committed manifest, then preserve its order.
        uint256[4] memory lengths;
        for (uint256 i; i < count; i++) {
            string memory prefix = string.concat(".blobs[", Strings.toString(i), "]");
            bytes32 kind = keccak256(bytes(fixtureVm.parseJsonString(manifest, string.concat(prefix, ".group"))));
            if (kind == keccak256("records")) lengths[0]++;
            if (kind == keccak256("thumbnails")) lengths[1]++;
            if (kind == keccak256("dictionary")) lengths[2]++;
            if (kind == keccak256("animationSuffix")) lengths[3]++;
        }
        assets.records = new address[](lengths[0]);
        assets.thumbnails = new address[](lengths[1]);
        assets.dictionary = new address[](lengths[2]);
        assets.animationSuffix = new address[](lengths[3]);
        uint256[4] memory cursor;
        for (uint256 i; i < count; i++) {
            string memory prefix = string.concat(".blobs[", Strings.toString(i), "]");
            bytes32 kind = keccak256(bytes(fixtureVm.parseJsonString(manifest, string.concat(prefix, ".group"))));
            address blob = address(
                new ImmutableBlob(
                    fixtureVm.readFileBinary(
                        string.concat(
                            "output/onchain/final-v025/",
                            fixtureVm.parseJsonString(manifest, string.concat(prefix, ".file"))
                        )
                    )
                )
            );
            if (kind == keccak256("records")) assets.records[cursor[0]++] = blob;
            else if (kind == keccak256("thumbnails")) assets.thumbnails[cursor[1]++] = blob;
            else if (kind == keccak256("dictionary")) assets.dictionary[cursor[2]++] = blob;
            else if (kind == keccak256("animationSuffix")) assets.animationSuffix[cursor[3]++] = blob;
            else if (kind == keccak256("dictionaryIndex")) assets.dictionaryIndex = blob;
            else if (kind == keccak256("animationPrefix")) assets.animationPrefix = blob;
        }
        BearBullsArt realArt = new BearBullsArt(
            fixtureVm.parseJsonUint(manifest, ".supply"), fixtureVm.parseJsonBytes32(manifest, ".provenance"), assets
        );
        Drop realDrop = new Drop(address(this), TREASURY, u);
        realDrop.registerRelease(realArt, START + 1, root);
        realDrop.resume();
        vm.warp(START + 24 hours + 1);
        uint256 specimen = realArt.specimenId(8);
        vm.startPrank(who(900));
        u.faucet();
        u.approve(address(realDrop), 10e6);
        realDrop.mint(specimen, 0, new bytes32[](0));
        vm.stopPrank();
        require(realDrop.ownerOf(specimen) == who(900));
        require(keccak256(bytes(realDrop.tokenURI(specimen))) == keccak256(bytes(realArt.tokenURI(8))));
        require(bytes(realArt.imageURI(8)).length > 1000 && bytes(realArt.animationHTML(8)).length > 1000);
    }

    function testLaterReleasePreservesMetadataCountsAndRejectsDuplicateIds() public {
        vm.warp(START + 24 hours);
        for (uint256 i; i < 100; i++) {
            publicBuy(i, i);
        }
        bytes32 beforeMedia = keccak256(bytes(d.tokenURI(0)));
        BearBullsArt duplicate = BearBullsArt(address(new DropArtFixture(100, 0)));
        vm.expectRevert(Drop.DuplicateSpecimen.selector);
        d.registerRelease(duplicate, uint64(block.timestamp + 1), root);
        BearBullsArt next = BearBullsArt(address(new DropArtFixture(100, 100)));
        d.registerRelease(next, uint64(block.timestamp + 1), root);
        require(d.releaseCount() == 2 && d.totalReleased() == 200 && d.mintedBy(who(0)) == 1);
        require(keccak256(bytes(d.tokenURI(0))) == beforeMedia);
        vm.warp(block.timestamp + 24 hours + 1);
        vm.prank(who(0));
        vm.expectRevert(Drop.WalletLimit.selector);
        d.mint(100, 0, new bytes32[](0));
    }

    function testRoyaltyRoundingAndZeroSale() public view {
        (address receiver, uint256 amount) = d.royaltyInfo(9999, 0);
        require(receiver == TREASURY && amount == 0);
        (, amount) = d.royaltyInfo(0, 23);
        require(amount == 0);
        (, amount) = d.royaltyInfo(0, 24);
        require(amount == 1);
    }
}

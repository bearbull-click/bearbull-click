// Economics and phased pilot accepted on 2026-09-22. Mainnet payment integration,
// snapshot, launch date and deployment remain unverified; live stays false.
export const SALE_TERMS = Object.freeze({
  supply: 10_000,
  initialReleaseSupply: 100,
  maxReleaseSupply: 100,
  currency: 'USD',
  priceUsdCents: 1_000,
  paymentFamilies: Object.freeze(['USDG']),
  futurePaymentFamilies: Object.freeze(['ETH', 'STOCK_TOKEN']),
  stockTokenPolicy: 'verified-canonical-contracts-with-available-quotes',
  treasurySettlementTarget: 'USDG',
  launchFormat: 'phased',
  royaltyBps: 420,
  earlyAllocation: 50,
  eligibleWallets: 10_000,
  topTierWallets: 1_000,
  publicDelaySeconds: 86_400,
  bonusDelaySeconds: 172_800,
  standardWalletLimit: 1,
  topTierWalletLimit: 3,
  strategy: 'creature-first',
  collectionTokenRequired: false,
  liquidityRequired: false,
  rewardsRequired: false,
  live: false
});

export function mintPriceLabel(config) {
  if(config.pricingMode === 'usd') {
    return Number.isSafeInteger(config.priceUsdCents) && config.priceUsdCents > 0
      ? `$${(config.priceUsdCents / 100).toFixed(config.priceUsdCents % 100 ? 2 : 0)} USD`
      : 'To be decided';
  }
  return typeof config.priceWei === 'string' && /^\d+$/.test(config.priceWei)
    ? `${BigInt(config.priceWei)} wei` : 'To be decided';
}

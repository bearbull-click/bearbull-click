import test from "node:test";
import assert from "node:assert/strict";
import { ACTIVE_NETWORK, LAUNCH_CONFIG, ROBINHOOD_MAINNET, ROBINHOOD_TESTNET, launchBlockers, selectNetwork } from "../src/launch-config.mjs";

test("creature-first pilot keeps a 10K ceiling and $10 target, without requiring a coin or pool", () => {
  assert.equal(ACTIVE_NETWORK, ROBINHOOD_TESTNET);
  for (const network of [ROBINHOOD_MAINNET, ROBINHOOD_TESTNET]) assert.equal(Number(network.chainIdHex), network.chainId);
  assert.equal(LAUNCH_CONFIG.priceWei, null);
  assert.equal(LAUNCH_CONFIG.supply, 10_000);
  assert.equal(LAUNCH_CONFIG.priceUsdCents, 1_000);
  assert.equal(LAUNCH_CONFIG.mode,'phased');
  assert.equal(LAUNCH_CONFIG.initialReleaseSupply,100);
  assert.equal(LAUNCH_CONFIG.collectionTokenRequired,false);
  assert.equal(LAUNCH_CONFIG.liquidityRequired,false);
  assert.deepEqual(LAUNCH_CONFIG.paymentFamilies, ['USDG']);
  assert.deepEqual(LAUNCH_CONFIG.futurePaymentFamilies, ['ETH','STOCK_TOKEN']);
  assert(!launchBlockers().includes("Confirm the mint price"));
  assert(!launchBlockers().includes("Confirm the drop supply"));
  assert(launchBlockers().includes("Verify the USDG payment route and dollar pricing policy"));
  assert(launchBlockers().includes("Review independent collector interest before opening the pilot"));
  assert(launchBlockers().includes("Verify the mint transaction flow"));
});
const candidate = {
  ...LAUNCH_CONFIG, mode: "public", supply: 1000, pricingMode: 'native', priceWei: "0", termsFinalized: true, demandValidated:true,
  contractAddress: "0x1111111111111111111111111111111111111111", deploymentChainId: 46630,
  startsAt: "2030-01-01T00:00:00Z", metadataMode: "ipfs", metadataBaseUri: "ipfs://bafyexample/metadata/",
  provenanceHash: `0x${"a".repeat(64)}`, transactionAdapterReady: true
};
test("a launch cannot become ready through an address alone or wrong-chain deployment", () => {
  assert(launchBlockers({ ...LAUNCH_CONFIG, contractAddress: candidate.contractAddress }).length > 5);
  assert.deepEqual(launchBlockers(candidate), []);
  assert(launchBlockers(candidate, ROBINHOOD_MAINNET).includes("Verify the deployment network"));
  assert(launchBlockers({ ...candidate, contractAddress: `0x${"0".repeat(40)}` }).includes("Deploy and verify the mint contract"));
  assert(launchBlockers({ ...candidate, priceWei: "-1" }).includes("Confirm the mint price"));
  assert(launchBlockers({ ...candidate, metadataBaseUri: "ipfs://REPLACE/metadata/" }).includes("Publish permanent artwork and metadata"));
});

test('a USD sale requires valid cents and verified payment routes even if a native price is supplied', () => {
 const usd={...candidate,pricingMode:'usd',priceUsdCents:10000,paymentRoutesVerified:false};
 assert.deepEqual(launchBlockers(usd),['Verify the USDG payment route and dollar pricing policy']);
 assert.deepEqual(launchBlockers({...usd,paymentRoutesVerified:true}),[]);
 for(const priceUsdCents of [null,0,-100,100.5,Number.MAX_SAFE_INTEGER+1])assert(launchBlockers({...usd,priceUsdCents}).includes('Confirm the mint price'));
});
test('pilot cap and demand review remain required even when technical inputs are filled',()=>{
 for(const initialReleaseSupply of [0,101,10000,null,1.5])assert(launchBlockers({...candidate,initialReleaseSupply}).includes('Confirm the first release size (up to 100 creatures)'));
 assert(launchBlockers({...candidate,demandValidated:false}).includes('Review independent collector interest before opening the pilot'));
 assert.deepEqual(launchBlockers({...candidate,initialReleaseSupply:100}),[]);
});
test("community mode requires an Ethereum historical block and selected-wallet root", () => {
  const config = { ...candidate, mode: "community-waves", snapshotSourceChainId: 1 };
  assert.equal(launchBlockers(config).length, 2);
  assert.deepEqual(launchBlockers({ ...config, snapshotBlock: 24_000_000, merkleRoot: `0x${"b".repeat(64)}` }), []);
});
test("unknown Robinhood chain adds its verified parameters then checks the switch", async () => {
  const calls = [];
  const provider = { async request(call) {
    calls.push(call);
    if (calls.length === 1) throw Object.assign(new Error("Unknown chain"), { code: 4902 });
    return call.method === "eth_chainId" ? "0xb626" : null;
  }};
  assert.equal(await selectNetwork(provider), "0xb626");
  assert.deepEqual(calls.map((c) => c.method), ["wallet_switchEthereumChain", "wallet_addEthereumChain", "wallet_switchEthereumChain", "eth_chainId"]);
  assert.equal(calls[1].params[0].rpcUrls[0], ROBINHOOD_TESTNET.rpcUrl);
});
test("wallet rejection never adds a chain and a false switch success fails closed", async () => {
  let count = 0;
  await assert.rejects(selectNetwork({ request: async () => { count++; throw Object.assign(new Error("Rejected"), { code: 4001 }); } }), /Rejected/);
  assert.equal(count, 1);
  await assert.rejects(selectNetwork({ request: async ({ method }) => method === "eth_chainId" ? "0x1" : null }), /did not select/);
});

test("onchain readiness requires deployed art and verified mint media, never an IPFS URI", () => {
 const config={...candidate,metadataMode:"onchain",metadataBaseUri:null};
 assert.equal(launchBlockers(config).length,2);
 assert.deepEqual(launchBlockers({...config,artAddress:candidate.contractAddress,onchainMediaVerified:true}),[]);
 assert(launchBlockers({...candidate,metadataMode:"unknown"}).includes("Choose the metadata storage mode"));
});

test('phased launch needs verified snapshot, tier rules, root and royalty readback', () => {
 const config={...candidate,mode:'phased'};
 const pending=launchBlockers(config);
 assert(pending.includes('Verify the Robinhood NFT-holder snapshot and tier ranking'));
 assert(pending.includes('Publish the selected-wallet proof root'));
 assert(pending.includes('Verify 4.2% ERC-2981 royalties to the fixed treasury'));
 const ready={...config,snapshotBlock:123,snapshotBlockHash:`0x${'c'.repeat(64)}`,snapshotVerified:true,snapshotWalletCount:10000,snapshotTopTierCount:1000,merkleRoot:`0x${'b'.repeat(64)}`,royaltyVerified:true};
 assert.deepEqual(launchBlockers(ready),[]);
 for (const change of [{snapshotSourceChainId:1},{snapshotWalletCount:9999},{snapshotTopTierCount:999},{snapshotVerified:false},{snapshotBlockHash:null}]) assert(launchBlockers({...ready,...change}).includes('Verify the Robinhood NFT-holder snapshot and tier ranking'));
 for (const change of [{royaltyBps:500},{royaltyVerified:false}]) assert(launchBlockers({...ready,...change}).includes('Verify 4.2% ERC-2981 royalties to the fixed treasury'));
 for (const change of [{earlyAllocation:100},{publicDelaySeconds:1},{bonusDelaySeconds:86400},{topTierWalletLimit:4},{standardWalletLimit:3},{initialReleaseSupply:99}]) assert(launchBlockers({...ready,...change}).includes('Verify the 50/50 allocation and phased wallet limits'));
});
